-- Remove all required data

DELETE FROM `#__vm_auth_group`;
DELETE FROM `#__vm_country`;
DELETE FROM `#__vm_creditcard`;
DELETE FROM `#__vm_currency`;
DELETE FROM `#__vm_manufacturer`;
DELETE FROM `#__vm_manufacturer_category`;
DELETE FROM `#__vm_shipping_carrier`;
DELETE FROM `#__vm_shipping_rate`;
DELETE FROM `#__vm_shopper_group`;
DELETE FROM `#__vm_shopper_vendor_xref`;
DELETE FROM `#__vm_state`;
DELETE FROM `#__vm_vendor`;
DELETE FROM `#__vm_vendor_category`;
DELETE FROM `#__vm_zone_shipping`;