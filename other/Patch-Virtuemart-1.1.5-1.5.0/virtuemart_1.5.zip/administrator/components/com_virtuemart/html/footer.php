<?php
if( !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: footer.php 2225 2010-01-19 23:18:41Z rolandd $
* @package VirtueMart
* @subpackage classes
* @copyright Copyright (C) 2004-2007 soeren - All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.org
*/
?>
<br />
<br />
<div align="center">
	<a href="http://virtuemart.org" target="_blank" style="display:block;width:90%; filter: alpha(opacity=60);" onmouseover="if( this.filters) { this.filters.alpha.opacity=100; }" onmouseout="if( this.filters) { this.filters.alpha.opacity=60; }">
    		<img align="middle" style="-moz-opacity: 0.6;" onmouseover="this.style.MozOpacity=1.0;" onmouseout="this.style.MozOpacity = 0.6;" src="<?php echo JURI::root().'/administrator/components/com_virtuemart/assets/images/vm_pblogo.png'; ?>" border="0" alt="Powered by VirtueMart" />
	</a>
</div>
