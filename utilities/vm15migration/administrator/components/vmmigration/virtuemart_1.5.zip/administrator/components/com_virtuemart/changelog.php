<?php
/**
 * VirtueMart Change Log
 *
 * @package	VirtueMart
 * @copyright Copyright (c) 2009 VirtueMart Team. All rights reserved.
 */
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

Legend:

* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note


-------------------- 1.5.0 Stable Release [Release date here] ------------------
^ Landing page converted to MVC
^ Media handling converted to MVC
^ Product listing converted to MVC
^ Administrator menu converted to MVC helper
^ Country maintenance converted to MVC
^ Credit card maintenance converted to MVC
^ Currency maintenance converted to MVC
^ Coupon maintenance converted to MVC
+ Added the ability to publish/unpublish countries
^ Coupon maintenance converted to MVC
^ Shipping Carrier maintenance converted to MVC
^ Shipping Rate maintenance converted
^ Order Status maintenance page converted to MVC