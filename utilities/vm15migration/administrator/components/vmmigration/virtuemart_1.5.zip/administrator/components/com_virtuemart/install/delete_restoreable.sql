-- VirtueMart table SQL script
-- This will delete all the tables installed with install.sql of VirtueMart

DROP TABLE `#__vm_function`, `#__vm_menu_admin`, `#__vm_module`, `#__vm_order_status`, `#__vm_payment_method`, `#__vm_plugins`, `#__vm_userfield`, `#__vm_userfield_values`, `#__vm_country`, `#__vm_state`,`#__vm_currency`;